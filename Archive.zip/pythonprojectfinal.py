#details of creator of this code on autolab
from Tkinter import *
from PIL import Image, ImageTk, ImageDraw, ImageFont
from re import *
global imageX
#The following program works if the images I detailed below
#are in the same folder as this file

#additionally with the exception of C6H12O6
#all entries should include all lowercase letters
#the use of the program relies on the entry of inputs
#in accordance to the standard chemical nomenclature adopted

#this function checks the chemical name inputed an detects if it
#is an alcohol with a prefix
#if the user specified a location to place the OH group
#this function will return the location of the OH group
#while also changing the input to where
#it only contains the root alcohol name
def n_alcohol(chemical_name):
    for i in range(len(chemical_name)):
        if chemical_name[i]=="-" and chemical_name[len(chemical_name)-4:]=='anol':
            chemical_name=chemical_name[i+1:len(chemical_name)-4]
            return i
    return -1

#this function takes an input of chemical name
#and if the input is an alcohol that has a defined
#OH group the function will return the name of the alcohol
#without the preceding number and dash
#i.e. the root name indicating the alcohol
def n_alcohol_changename(chemical_name):
    for i in range(len(chemical_name)):
        if chemical_name[i]=="-":
            chemical_name=chemical_name[i+1:]
            return chemical_name
        

#this function is the master function of the whole program
#in this function the user input is handled to create the chemical structure
#the user specifies in the entry box of the GUI
#using the PIL library, the letters representing atoms are placed
#in their appropriate locations and then depending on the structure
#lines representing bonds are drawn
def draw_chem_structure():
    global imageX
    #the file with the letters of the alphabet
    im1 = Image.open("ChemLetters.tiff")
    #to get the atom name we crop the previous image
    Carbon = im1.crop((50,12,68,32))
    Oxygen = im1.crop((26,42,46,63))
    Hydrogen=im1.crop((134,12,152,32))
    Phosphorus=im1.crop((46,42,61,63))
    Nitrogen = im1.crop((8,42,26,63))
    #this image serves as the background for displaying the image
    #with the chemical structure drawn on it
    im = Image.open("solidsquare.png")
    #this will be used to draw structures
    draw = ImageDraw.Draw(im, "RGBA")
    #the following sets the starting location of the image
    x=400
    y=400
    #the following are dictionaries that contain the root names and prefixes
    #of major organic chemistry molecules
    #the values associated with the name indicate how many
    #carbon-carbon bonds are formed
    alcohol_prefix= { 'meth' : 0, 'eth' : 1, 'prop' : 2, 'but' : 3, 'pent' : 4, 'hex' : 5, 'hept' : 6, 'oct' : 7, 'non' : 8, 'dec' : 9}
    alkane_prefix= { 'meth' : 0, 'eth' : 1, 'prop' : 2, 'but' : 3, 'pent' : 4, 'hex' : 5, 'hept' : 6, 'oct' : 7, 'non' : 8, 'dec' : 9}
    ############ ALKANES
    chemical_name=chemical_name_entry.get()
    original_entry=chemical_name
    ####AS METHANE AND METHANOL ARE EXCEPTIONS TO SKELETAL STRUCTURE
    ####THEY REQUIRE THE TRADITIONAL MODEL
    #draws methane
    if chemical_name=="methane":
        im.paste(Carbon,(x,y))
        draw.line([(x-20, y+10),(x,y+10)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x-40,y))
        draw.line([(x+20, y+10),(x+40,y+10)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x+40,y))
        draw.line([(x+10, y-20),(x+10,y)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x,y-40))
        draw.line([(x+10, y+20),(x+10,y+40)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x,y+40))
        #used to erase any text in the location prior to this function call
        screen.create_rectangle(20,320,380,380,outline="white",fill="white")
        #displays name of the user input chemical name
        screen.create_text(200,350,fill="black",font="Times 14 bold",
        text=chemical_name)
    #draws methanol
    if chemical_name=="methanol":
        im.paste(Carbon,(x,y))
        draw.line([(x-20, y+10),(x,y+10)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x-40,y))
        draw.line([(x+20, y+10),(x+40,y+10)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x+40,y))
        im.paste(Hydrogen,(x+60,y))
        draw.line([(x+10, y-20),(x+10,y)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x,y-40))
        draw.line([(x+10, y+20),(x+10,y+40)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x,y+40))
        #used to erase any text in the location prior to this function call
        screen.create_rectangle(20,320,380,380,outline="white",fill="white")
        #displays name of the user input chemical name
        screen.create_text(200,350,fill="black",font="Times 14 bold",
        text=chemical_name)
    #draws methanoic acid
    if chemical_name=="methanoic acid":
        im.paste(Carbon,(x,y))
        draw.line([(x+5, y),(x+5,y-20)], fill=(0,0,0), width=2)
        draw.line([(x+15, y),(x+15,y-20)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x,y-40))
        draw.line([(x, y+13),(x-20,y+33)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x-40,y+33))
        draw.line([(x+20, y+13),(x+40,y+33)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x+40,y+33))
        im.paste(Hydrogen,(x+60,y+33))
        #used to erase any text in the location prior to this function call
        screen.create_rectangle(20,320,380,380,outline="white",fill="white")
        #displays name of the user input chemical name
        screen.create_text(200,350,fill="black",font="Times 14 bold",
        text=chemical_name)
    #the following condition checks to see if the chemical name input
    #is an alkane
    if chemical_name[len(chemical_name)-3:]=='ane':
        #chemical_name now consists of the root name
        chemical_name=chemical_name[:len(chemical_name)-3]
        if chemical_name in alkane_prefix and original_entry[len(original_entry)-3:]=='ane' and original_entry!="methane":
            #draws the number of carbon-carbon bonds required for the root name
            for i in range(alkane_prefix[chemical_name]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
            #used to erase any text in the location prior to this function call
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            #displays name of the user input chemical name
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text=original_entry)
    #################### END ALKANES

    ### ALCOHOLS

    #haspos is a variable that detects if the user input is an alcohol
    #with an OH group specified
    #the variable haspos will then store the position of the  OH group
    haspos=n_alcohol(chemical_name)
    #reduce chemical name to root
    if chemical_name[len(chemical_name)-4:]=='anol':
        chemical_name=chemical_name[:len(chemical_name)-4]
    #if a position was specified with by the user
    if haspos!=-1:
        #convert string to integer
        attach_OH=int(chemical_name[:1])
        #initalizes boolean for if the user put an invalid number
        #preceding the dash i.e. 8-hexanol since there is no Carbon 8
        #this should not display an image, rather the screen will be blank
        exception2=True
        #remainder holds the root name of the alcohol
        remainder=n_alcohol_changename(chemical_name)
        if remainder in alcohol_prefix and original_entry[len(original_entry)-4:]=='anol' and original_entry!="methanol":
            #this boolean will attach the OH group in the right location
            #once it does so, it will be changed to False so as not to add
            #extra OHs
            exception1=True
            if attach_OH>alcohol_prefix[remainder]:
                exception2=False
            #draws the number of carbon-carbon bonds required for the root name
            for i in range(alcohol_prefix[remainder]):
                if i % 2 == 0 and exception2!=False:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    #places the OH group at the location specified by user
                    if i==attach_OH-2 or alcohol_prefix[remainder]-attach_OH==-1:
                        draw.line([(x+20, y+20),(x+20,y+40)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+10,y+40))
                        im.paste(Hydrogen,(x+10,y+60))
                    if attach_OH==1 and exception1==True and exception2!=False:
                        draw.line([(x, y),(x-10, y+10)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x-30,y+10))
                        im.paste(Hydrogen,(x-50,y+10))
                        exception1=False
                    x=x+20
                    y=y+20                        
                if i % 2 == 1 and exception2!=False:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    #places the OH group at the location specified by user
                    if i==attach_OH-2:
                        draw.line([(x+20, y-20),(x+20,y-40)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+10,y-60))
                        im.paste(Hydrogen,(x+10,y-80))
                    x=x+20
                    y=y-20
            #used to erase any text in the location prior to this function call
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            #displays name of the user input chemical name
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text=original_entry)
    #this part is executed if the user didn't specify where to place OH
    #by default, the OH is placed on the last Carbon
    else:
        if chemical_name in alcohol_prefix and original_entry[len(original_entry)-4:]=='anol' and original_entry!="methanol":
            for i in range(alcohol_prefix[chemical_name]):
                #draws the number of carbon-carbon bonds required for the root name
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    if i==alcohol_prefix[chemical_name]-1:
                        draw.line([(x+20, y+20),(x+30,y+10)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+30,y))
                        im.paste(Hydrogen,(x+50,y))
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    if i==alcohol_prefix[chemical_name]-1:
                        draw.line([(x+20, y-20),(x+30,y-10)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+30,y-20))
                        im.paste(Hydrogen,(x+50,y-20))
                    x=x+20
                    y=y-20
            #used to erase any text in the location prior to this function call
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            #displays name of the user input chemical name
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text=original_entry)

    ###############END ALCOHOL

    ### CARBOXYLIC ACID

    #the following condition checks to see if the chemical name input
    #is a carboxylic acid
    if chemical_name[len(chemical_name)-10:]=='anoic acid':
        chemical_name=chemical_name[:len(chemical_name)-10]
    if haspos!=-1:
        attach_OH=int(chemical_name[:1])
    #this part of the code draws the necessary lines and places the atoms accordingly
    #to make the carboxylic acid
    else:
        if chemical_name in alcohol_prefix and original_entry[len(original_entry)-10:]=='anoic acid' and original_entry!="methanoic acid":
            for i in range(alcohol_prefix[chemical_name]):
                #draws the number of carbon-carbon bonds required for the root name
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    if i==alcohol_prefix[chemical_name]-1:
                        draw.line([(x+17, y+20),(x+17,y+40)], fill=(0,0,0), width=2)
                        draw.line([(x+23, y+20),(x+23,y+40)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+11,y+40))
                        draw.line([(x+20, y+20),(x+30,y+10)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+30,y))
                        im.paste(Hydrogen,(x+50,y))
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    if i==alcohol_prefix[chemical_name]-1:
                        draw.line([(x+17, y-20),(x+17,y-40)], fill=(0,0,0), width=2)
                        draw.line([(x+23, y-20),(x+23,y-40)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+11,y-60))
                        draw.line([(x+20, y-20),(x+30,y-10)], fill=(0,0,0), width=2)
                        im.paste(Oxygen,(x+30,y-20))
                        im.paste(Hydrogen,(x+50,y-20))
                    x=x+20
                    y=y-20
            #used to erase any text in the location prior to this function call
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            #displays name of the user input chemical name
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text=original_entry)

    ###############END CARBOXYLIC ACIDS

    ###KETONES

    #the following condition checks to see if the chemical name input
    #is a ketone
    if chemical_name[len(chemical_name)-5:]=='anone':
        chemical_name=chemical_name[:len(chemical_name)-5]
        if chemical_name in alkane_prefix and original_entry[len(original_entry)-5:]=='anone':
            for i in range(alkane_prefix[chemical_name]):
                #draws the number of carbon-carbon bonds required for the root name
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
                if i==0:
                    draw.line([(x-4, y),(x-4,y+20)], fill=(0,0,0), width=2)
                    draw.line([(x+4, y),(x+4,y+20)], fill=(0,0,0), width=2)
                    im.paste(Oxygen,(x-10,y+20))
            #used to erase any text in the location prior to this function call
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            #displays name of the user input chemical name
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text=original_entry)

    #####END KETONES
            
    ####MONOSACCHARIDES
    #by default, if the user types in C6H12O6,
    #glucose will be displayed (more particular alphaglucopyranose)
    #this is because it is the most commonly known sugar for this chemical formula
    #however, with the help menu, the user can see the different conformations
    #of the chemical formula C6H12O6
    if chemical_name[len(chemical_name)-8:]=='pyranose' or chemical_name=="C6H12O6":
        #builds the basic structure of all pyranoses (6-ringed carbons)
        draw.line([(x+20, y),(x+70,y+70)], fill=(0,0,0), width=2)#end at C2
        draw.line([(x+70, y+70),(x+20,y+140)], fill=(0,0,0), width=2)
        draw.line([(x-50, y+140),(x+20,y+140)], fill=(0,0,0), width=2)
        draw.line([(x-50, y+140),(x-100,y+70)], fill=(0,0,0), width=2)
        draw.line([(x-50, y),(x-100,y+70)], fill=(0,0,0), width=2)
        draw.line([(x-50, y),(x,y)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x+7,y-10))
        #alpha and beta refer to the configuration of Carbon 1
        #this can be up for beta and down for alpha
        #it depends on where the Oxygen attacks the anomeric Carbon from
        if chemical_name[0:5]=='alpha' or chemical_name=="C6H12O6":
            draw.line([(x+70, y+70),(x+80,y+80)], fill=(0,0,0), width=2)#end at C2
            im.paste(Oxygen,(x+80,y+80))
            im.paste(Hydrogen,(x+100,y+80))
        if chemical_name[0:4]=='beta':
            draw.line([(x+70, y+70),(x+80,y+60)], fill=(0,0,0), width=2)#end at C2
            im.paste(Oxygen,(x+80,y+50))
            im.paste(Hydrogen,(x+100,y+50))
        #uses regular expressions to find the root name in the user input
        #for the eight sugars of 6-ringed Carbons
        glucose=search("gluco",chemical_name)
        galactose=search("galacto",chemical_name)
        allose=search("allo",chemical_name)
        altrose=search("altro",chemical_name)
        mannose=search("manno",chemical_name)
        gulose=search("gulo",chemical_name)
        idose=search("ido",chemical_name)
        talose=search("talo",chemical_name)
        #the root name determines the configuration of the OH group
        #from Carbon 2 to Carbon 4
        #the OH is either above the plane or below it
        if glucose or chemical_name=="C6H12O6":
            draw.line([(x+20,y+140),(x+20,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+170))
            im.paste(Hydrogen,(x+30,y+170))#DOWN C2
            draw.line([(x-50,y+140),(x-50,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+90))
            im.paste(Hydrogen,(x-40,y+90))#UP C3
            draw.line([(x-100,y+70),(x-100,y+100)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+100))
            im.paste(Hydrogen,(x-130,y+100))#DOWN C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Glucose")
        
        elif galactose:
            draw.line([(x+20,y+140),(x+20,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+170))
            im.paste(Hydrogen,(x+30,y+170))#DOWN C2
            draw.line([(x-50,y+140),(x-50,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+90))
            im.paste(Hydrogen,(x-40,y+90))#UP C3
            draw.line([(x-100,y+70),(x-100,y+40)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+20))
            im.paste(Hydrogen,(x-130,y+20))#UP C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Galactose")
        
        elif allose:
            draw.line([(x+20,y+140),(x+20,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+170))
            im.paste(Hydrogen,(x+30,y+170))#DOWN C2
            draw.line([(x-50,y+140),(x-50,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+170))
            im.paste(Hydrogen,(x-40,y+170))#DOWN C3
            draw.line([(x-100,y+70),(x-100,y+100)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+100))
            im.paste(Hydrogen,(x-130,y+100))#DOWN C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Allose")
        
        elif altrose:
            draw.line([(x+20,y+140),(x+20,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+90))
            im.paste(Hydrogen,(x-10,y+90))#UP C2
            draw.line([(x-50,y+140),(x-50,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+170))
            im.paste(Hydrogen,(x-40,y+170))#DOWN C3
            draw.line([(x-100,y+70),(x-100,y+100)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+100))
            im.paste(Hydrogen,(x-130,y+100))#DOWN C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Altrose")
        
        elif mannose:
            draw.line([(x+20,y+140),(x+20,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+90))
            im.paste(Hydrogen,(x-10,y+90))#UP C2
            draw.line([(x-50,y+140),(x-50,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+90))
            im.paste(Hydrogen,(x-40,y+90))#UP C3
            draw.line([(x-100,y+70),(x-100,y+100)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+100))
            im.paste(Hydrogen,(x-130,y+100))#DOWN C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Mannose")
        
        elif gulose:
            draw.line([(x+20,y+140),(x+20,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+170))
            im.paste(Hydrogen,(x+30,y+170))#DOWN C2
            draw.line([(x-50,y+140),(x-50,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+170))
            im.paste(Hydrogen,(x-40,y+170))#DOWN C3
            draw.line([(x-100,y+70),(x-100,y+40)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+20))
            im.paste(Hydrogen,(x-130,y+20))#UP C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Gulose")
        
        elif idose:
            draw.line([(x+20,y+140),(x+20,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+90))
            im.paste(Hydrogen,(x-10,y+90))#UP C2
            draw.line([(x-50,y+140),(x-50,y+170)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+170))
            im.paste(Hydrogen,(x-40,y+170))#DOWN C3
            draw.line([(x-100,y+70),(x-100,y+40)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+20))
            im.paste(Hydrogen,(x-130,y+20))#UP C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Idose")
        
        elif talose:
            draw.line([(x+20,y+140),(x+20,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x+10,y+90))
            im.paste(Hydrogen,(x-10,y+90))#UP C2
            draw.line([(x-50,y+140),(x-50,y+110)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-60,y+90))
            im.paste(Hydrogen,(x-40,y+90))#UP C3
            draw.line([(x-100,y+70),(x-100,y+40)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-110,y+20))
            im.paste(Hydrogen,(x-130,y+20))#UP C4
            screen.create_rectangle(20,320,380,380,outline="white",fill="white")
            screen.create_text(200,350,fill="black",font="Times 14 bold",
            text="Talose")
        #draws the Carbon 5 and 6, which are the same in naturally
        #occuring monosaccharides
        draw.line([(x-50, y),(x-50,y-30)], fill=(0,0,0), width=2)
        im.paste(Carbon,(x-60,y-50))
        im.paste(Hydrogen,(x-40,y-50))
        im.paste(Hydrogen,(x-20,y-50))
        im.paste(Oxygen,(x,y-50))
        im.paste(Hydrogen,(x+20,y-50))

        ####### END MONOSACCHARIDES
        
    ###PHOSPHOLIPIDS
    #this dictionary contains the roots for the carbon chains
    #found in glycerophospholipids
    phospholipid_prefix= { 'laur' : 11, 'myrist' : 13, 'palmit' : 15, 'stear' : 17, 'arachid' : 19}
    #the following pattern is used in nomenclature for glycerophospholipids
    phospholipid_pattern="(1-[a-z]+oyl)-(2-[a-z]+oyl)-(3-phosphatid[a-z\s]+)"
    phospholipid_result=search(phospholipid_pattern,chemical_name)
    if phospholipid_result!= None:
        #each group refers to the three parts
        #that are variable in creating glycerophospholipids
        #first two refer to what carbon chain will be attached
        #last group refers to the head group
        phospholipid_one=phospholipid_result.group(1)
        phospholipid_two=phospholipid_result.group(2)
        phospholipid_three=phospholipid_result.group(3)
        #draw the basic fundamental aspects
        #of all glycerophospholipids in the program
        draw.line([(x-3, y),(x-3,y-20)], fill=(0,0,0), width=2)
        draw.line([(x+3, y),(x+3,y-20)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-10,y-40))
        draw.line([(x, y),(x-20,y+20)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-32,y+20))
        draw.line([(x-23, y+40),(x-23,y+60)], fill=(0,0,0), width=2)
        im.paste(Carbon,(x-32,y+60))
        draw.line([(x-12, y+80),(x+8,y+100)], fill=(0,0,0), width=2)
        draw.line([(x+3, y+100),(x+23,y+80)], fill=(0,0,0), width=2)
        im.paste(Carbon,(x-2,y+94))
        im.paste(Oxygen,(x+23,y+60))
        draw.line([(x+43, y+80),(x+63,y+100)], fill=(0,0,0), width=2)
        draw.line([(x+60, y+100),(x+60,y+120)], fill=(0,0,0), width=2)
        draw.line([(x+66, y+100),(x+66,y+120)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x+53,y+120))
        #for the first carbon chain to be attached to the Carbon
        #with the double bond O and OH attached
        #phospholipid_one will construct the Carbon chain associated
        #with the user input
        if "laur" in phospholipid_one:
            for i in range(phospholipid_prefix["laur"]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "myrist" in phospholipid_one:
            for i in range(phospholipid_prefix["myrist"]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "palmit" in phospholipid_one:
            for i in range(phospholipid_prefix["palmit"]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "stear" in phospholipid_one:
            for i in range(phospholipid_prefix["stear"]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "arachid" in phospholipid_one:
            for i in range(phospholipid_prefix["arachid"]):
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        #resets coordinates to default to allow
        #for further construction of glycerophospholipid
        x=400
        y=400
        x=x+63
        y=y+100
        #for the second carbon chain to be attached to the Carbon
        #with the double bond O and OH attached
        #phospholipid_two will construct the Carbon chain associated
        #with the user input
        if "laur" in phospholipid_two:
            for i in range(phospholipid_prefix["laur"]):
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "myrist" in phospholipid_two:
            for i in range(phospholipid_prefix["myrist"]):
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "palmit" in phospholipid_two:
            for i in range(phospholipid_prefix["palmit"]):
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "stear" in phospholipid_two:
            for i in range(phospholipid_prefix["stear"]):
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        elif "arachid" in phospholipid_two:
            for i in range(phospholipid_prefix["arachid"]):
                if i % 2 == 1:
                    draw.line([(x, y),(x+20,y+20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y+20
                if i % 2 == 0:
                    draw.line([(x, y),(x+20,y-20)], fill=(0,0,0), width=2)
                    x=x+20
                    y=y-20
        #reset coordinates
        x=400
        y=400
        #this section builds generic features for the head group
        #in these cases, it is a phosphate group of various types
        draw.line([(x+5, y+114),(x+5,y+134)], fill=(0,0,0), width=2)
        im.paste(Carbon,(x-4,y+134))
        draw.line([(x-4, y+154),(x-24,y+166)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-44,y+164))
        draw.line([(x-46, y+177),(x-66,y+197)], fill=(0,0,0), width=2)
        im.paste(Phosphorus,(x-78,y+195))
        draw.line([(x-63, y+214),(x-43,y+234)], fill=(0,0,0), width=2)
        draw.line([(x-68, y+222),(x-48,y+242)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-42,y+235))
        draw.line([(x-82, y+195),(x-102,y+175)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-122,y+155))
        draw.line([(x-82, y+215),(x-102,y+235)], fill=(0,0,0), width=2)
        im.paste(Oxygen,(x-116,y+233))
        #if phospholipid_three specifies that the head group
        #is phosphatidic acid
        if phospholipid_three[12:]=="ic acid":
            im.paste(Hydrogen,(x-142,y+155))
        #if phospholipid_three specifies that the head group
        #is phosphatidylcholine
        elif phospholipid_three[12:]=="ylcholine":
            draw.line([(x-122, y+175),(x-142,y+195)], fill=(0,0,0), width=2)
            draw.line([(x-142,y+195),(x-172,y+165)], fill=(0,0,0), width=2)
            draw.line([(x-172,y+165),(x-205,y+170)], fill=(0,0,0), width=2)
            im.paste(Nitrogen,(x-225,y+160))
            draw.line([(x-215, y+160),(x-195,y+140)], fill=(0,0,0), width=2)
            im.paste(Carbon,(x-203,y+120))
            im.paste(Hydrogen,(x-203,y+100))
            im.paste(Hydrogen,(x-223,y+120))
            im.paste(Hydrogen,(x-183,y+120))
            draw.line([(x-225,y+160),(x-250,y+145)], fill=(0,0,0), width=2)
            im.paste(Carbon,(x-270,y+135))
            im.paste(Hydrogen,(x-270,y+115))
            im.paste(Hydrogen,(x-270,y+155))
            im.paste(Hydrogen,(x-290,y+135))
            draw.line([(x-225,y+180),(x-240,y+205)], fill=(0,0,0), width=2)
            im.paste(Carbon,(x-250,y+205))
            im.paste(Hydrogen,(x-270,y+205))
            im.paste(Hydrogen,(x-230,y+205))
            im.paste(Hydrogen,(x-250,y+225))
        #if phospholipid_three specifies that the head group
        #is phosphatidylserine
        elif phospholipid_three[12:]=="ylserine":
            draw.line([(x-122, y+155),(x-142,y+135)], fill=(0,0,0), width=2)
            draw.line([(x-142, y+135),(x-162,y+155)], fill=(0,0,0), width=2)
            draw.line([(x-162, y+155),(x-162,y+177)], fill=(0,0,0), width=2)
            draw.line([(x-162, y+173),(x-182,y+195)], fill=(0,0,0), width=2)
            draw.line([(x-162, y+181),(x-182,y+201)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-202,y+188))
            draw.line([(x-162, y+177),(x-142,y+197)], fill=(0,0,0), width=2)
            im.paste(Oxygen,(x-142,y+188))
            draw.line([(x-162, y+155),(x-182,y+133)], fill=(0,0,0), width=2)
            im.paste(Nitrogen,(x-200,y+125))
            im.paste(Hydrogen,(x-200,y+105))
            im.paste(Hydrogen,(x-200,y+145))
            im.paste(Hydrogen,(x-220,y+125))
        #used to erase any text in the location prior to this function call
        screen.create_rectangle(20,320,380,380,outline="white",fill="white")
        #displays name of the user input chemical name
        screen.create_text(200,350,fill="black",font="Times 14 bold",
        text=chemical_name)
    #draws a water molecule (fairly simple!)
    if original_entry=="water":
        im.paste(Oxygen,(x-10,y-20))
        draw.line([(x+9, y),(x+30,y+10)], fill=(0,0,0), width=2)
        draw.line([(x-10, y),(x-30,y+10)], fill=(0,0,0), width=2)
        im.paste(Hydrogen,(x-50,y+10))
        im.paste(Hydrogen,(x+30,y+10))
        #used to erase any text in the location prior to this function call
        screen.create_rectangle(20,320,380,380,outline="white",fill="white")
        #displays name of the user input chemical name
        screen.create_text(200,350,fill="black",font="Times 14 bold",
        text=chemical_name)
    #resizes the original image to the size below
    im.thumbnail((400,400), Image.ANTIALIAS)
    #creates photoimage object
    imageX = ImageTk.PhotoImage(im)
    #changes screen to display the chemical structre
    screen.itemconfig(imageRef, image = imageX)

#makes Tkinter screen
root=Tk()
#hides mainscreen
root.withdraw()
#creates a new window which will display all features
possible_options=Toplevel()
#sets size of the window
possible_options.geometry("600x600")
#sets title of the window
possible_options.title("ENTER CHEMICAL NAME")
#creates Canvas object in Tkinter to display image of chemical structure
screen=Canvas(possible_options, width=400, height=400, bg="white")
#imback is the background image used
imback = Image.open("solidsquare.png")
#imback1 is the background image used as a PhotoImage object
imback1 = ImageTk.PhotoImage(imback)
#imageRef is the background of desired size holding the image of chemical structure
imageRef = screen.create_image(202,202,image=imback1)
#place screen in grid
screen.grid(row=5,column=1)
#creates Canvas object in Tkinter to display the help menu for
#monosaccharides and glycerophospholipids
helpscreen=Canvas(possible_options, width=190, height=400, bg="black")
#place helpscreen in grid
helpscreen.grid(row=5,column=2)
#the following items help the user with knowing basic names
#of the monosaccharides and carbon chains for glycerophospholipids
helpscreen.create_text(7,10,fill="white",font="Times 14 bold underline ",anchor= "nw",text="HELPFUL TIPS:")
helpscreen.create_text(7,40,fill="white",font="Times 11 underline",anchor= "nw",text="Configurations of OH on C2-C4 atoms:")
helpscreen.create_text(7,55,fill="white",font="Times 10",anchor= "nw",text="Allose=")
helpscreen.create_text(7,65,fill="white",font="Times 10",anchor= "nw",text="Altrose=")
helpscreen.create_text(7,75,fill="white",font="Times 10",anchor= "nw",text="Glucose=")
helpscreen.create_text(7,85,fill="white",font="Times 10",anchor= "nw",text="Mannose=")
helpscreen.create_text(7,95,fill="white",font="Times 10",anchor= "nw",text="Gulose=")
helpscreen.create_text(7,105,fill="white",font="Times 10",anchor= "nw",text="Idose=")
helpscreen.create_text(7,115,fill="white",font="Times 10",anchor= "nw",text="Galactose=")
helpscreen.create_text(7,125,fill="white",font="Times 10",anchor= "nw",text="Talose=")
helpscreen.create_text(63,55,fill="white",font="Times 10",anchor= "nw",text="DDD")
helpscreen.create_text(63,65,fill="white",font="Times 10",anchor= "nw",text="UDD")
helpscreen.create_text(63,75,fill="white",font="Times 10",anchor= "nw",text="DUD")
helpscreen.create_text(63,85,fill="white",font="Times 10",anchor= "nw",text="UUD")
helpscreen.create_text(63,95,fill="white",font="Times 10",anchor= "nw",text="DDU")
helpscreen.create_text(63,105,fill="white",font="Times 10",anchor= "nw",text="UDU")
helpscreen.create_text(63,115,fill="white",font="Times 10",anchor= "nw",text="DUU")
helpscreen.create_text(63,125,fill="white",font="Times 10",anchor= "nw",text="UUU")
helpscreen.create_text(7,140,fill="white",font="Times 11 underline",anchor= "nw",text="Root Names for Glycerophospholipids:")
helpscreen.create_text(7,155,fill="white",font="Times 10",anchor= "nw",text="Lauric acid=")
helpscreen.create_text(7,165,fill="white",font="Times 10",anchor= "nw",text="Myristic acid=")
helpscreen.create_text(7,175,fill="white",font="Times 10",anchor= "nw",text="Palmitic acid=")
helpscreen.create_text(7,185,fill="white",font="Times 10",anchor= "nw",text="Stearic acid=")
helpscreen.create_text(7,195,fill="white",font="Times 10",anchor= "nw",text="Arachidic acid=")
helpscreen.create_text(85,155,fill="white",font="Times 10",anchor= "nw",text="12 Carbons")
helpscreen.create_text(85,165,fill="white",font="Times 10",anchor= "nw",text="14 Carbons")
helpscreen.create_text(85,175,fill="white",font="Times 10",anchor= "nw",text="16 Carbons")
helpscreen.create_text(85,185,fill="white",font="Times 10",anchor= "nw",text="18 Carbons")
helpscreen.create_text(85,195,fill="white",font="Times 10",anchor= "nw",text="20 Carbons")
#instruction for user
chemical_name_ask=Label(possible_options,text="Please enter a valid chemical name: ")
chemical_name_ask.grid(row=0,column=0)
#place for the user to input chemical name
chemical_name_entry=Entry(possible_options)
chemical_name_entry.grid(row=1,column=0)
#if user doesn't know what category
#they can press the enter button
btn=Button(possible_options, text="Enter", command=draw_chem_structure)
btn.grid(row=2,column=0)
#preferably, the user should click the button relating to
#the field their structure is part of
#(although no negative effects if wrong button pressed)
btn1=Button(possible_options, text="Organic Chemistry", command=draw_chem_structure)
btn1.grid(row=3,column=0)
btn2=Button(possible_options, text="Biochemistry", command=draw_chem_structure)
btn2.grid(row=4,column=0)
#the following may be adapted in the future for cool features
#Stay Tuned!
def key(event):
    print "pressed", repr(event.char)
    if repr(event.char)>(50,50) and repr(event.char)<(300,300):
        print "yes!"
    return "pressed", repr(event.char)

def callback(event):
    print "clicked at", event.x, event.y
    if event.x>111 and event.x<126 and event.y>200 and event.y<212:
        print "yes"
screen.bind("<Key>", key)
screen.bind("<Button-1>", callback)
screen.grid(row=5,column=0)
#run mainloop
root.mainloop()
#THE END!
root.destroy()

